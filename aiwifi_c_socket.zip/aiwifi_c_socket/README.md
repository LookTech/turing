修改源码中的`aes_key`和`api_key`为自己的账号



编译`gcc cJSON.c aes.c aiwifi.c -o aiwifi -lpthread -lm`



执行`./aiwifi <audiofile>`