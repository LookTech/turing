#include <pthread.h> 
#include <stdio.h> 
#define NUM_THREADS     5 
 
int flag = 1;
void *PrintHello(void *threadid) 
{ 
   while(flag < 10)
   {
   int tid; 
   tid = (int)threadid; 
   printf("Hello World! It's me, thread #%d!\n", tid); 
   }
   pthread_exit(NULL); 
} 
 
int main (int argc, char *argv[]) 
{ 
   pthread_t threads; 
   int rc, t; 
   printf("In main: creating thread %d\n", t); 
   rc = pthread_create(&threads, NULL, PrintHello, (void *)t); 
   if (rc){ 
     printf("ERROR; return code from pthread_create() is %d\n", rc); 
     exit(-1); 
   }
   int i;
   for(i=0;i<12;i++)
   {
       sleep(1);
       flag++;
   }
   
   //pthread_exit(NULL); 
} 